﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tamagotchi_final_YCH
{
    public partial class frmTamagotchiFinal : Form
    {

        private int _score;
        private bool _statusscore = false;
        private bool _message = true;
        public frmTamagotchiFinal()
        {
            InitializeComponent();
        }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }

        private void btnEten_Click(object sender, EventArgs e)
        {

            try
            {
                pbEten.Value = pbEten.Value + 3;
            }
            catch (System.Exception boodschap)
            {
                MessageBox.Show(boodschap.Message);
            }
        }

        private void lblWelzijn_Click(object sender, EventArgs e)
        {

        }

        private void btnDrinken_Click(object sender, EventArgs e)
        {
            try
            {
                pbDrinken.Value = pbDrinken.Value + 3;
            }
            catch (System.Exception boodschap)
            {
                MessageBox.Show(boodschap.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pbEten.Increment(-1);
            pbDrinken.Increment(-1);

            if (pbEten.Value < 1 || pbDrinken.Value < 1)
            {
                pbWelzijn.Increment(-1);
            }

            if (pbWelzijn.Value > 75)
            {
                pbxAfbeelding.Image = Properties.Resources.snorlex_blij;
                pbxAfbeelding.Refresh();
            }
            else if (pbWelzijn.Value < 75 && pbWelzijn.Value > 50)
            {
                pbxAfbeelding.Image = Properties.Resources.snorlex_normaal;
                pbxAfbeelding.Refresh();
            }
            else if (pbWelzijn.Value < 50 && pbWelzijn.Value > 25)
            {
                pbxAfbeelding.Image = Properties.Resources.snorlex_sad;
                pbxAfbeelding.Refresh();
            }
            else if (pbWelzijn.Value < 25 && pbWelzijn.Value > 1)
            {
                pbxAfbeelding.Image = Properties.Resources.snorlex_ziek;
                pbxAfbeelding.Refresh();
            }
            else if (pbWelzijn.Value == 0)
            {
                pbxAfbeelding.Image = Properties.Resources.Snorlex_dood;
                _statusscore = true;
                if (_message)
                {
                    _message = false;
                    MessageBox.Show("Jouw score is:" + _score);
                    // Application.Exit();

                }
                pbxAfbeelding.Refresh();
            }
            if (_statusscore != true)
            {
                lblScore.Text = _score++.ToString();
            }
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btnUitleg_Click(object sender, EventArgs e)
        {
            
            btnStartGame.Visible = false;
            pbDrinken.Visible = true;
            pbEten.Visible = true;
            pbWelzijn.Visible=true;
            pbxAfbeelding.Visible = true;
            pbxStart.Visible = false;
            btnDrinken.Visible = true;  
            btnEten.Visible = true;
            BtnStart.Visible = true;
            lblDrinken.Visible = true;
            lblScore.Visible = true;
            lblWelzijn.Visible = true;
            lblEten.Visible = true;

        }

        private void pbStart_Click(object sender, EventArgs e)
        {
            if (pbWelzijn.Value == 100)
            {
                pbxAfbeelding.Image = Properties.Resources.start;
            }
        }
    }
}
