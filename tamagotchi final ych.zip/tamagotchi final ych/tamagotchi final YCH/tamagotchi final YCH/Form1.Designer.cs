﻿namespace tamagotchi_final_YCH
{
    partial class frmTamagotchiFinal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblScore = new System.Windows.Forms.Label();
            this.btnEten = new System.Windows.Forms.Button();
            this.btnDrinken = new System.Windows.Forms.Button();
            this.lblEten = new System.Windows.Forms.Label();
            this.pbEten = new System.Windows.Forms.ProgressBar();
            this.lblDrinken = new System.Windows.Forms.Label();
            this.pbDrinken = new System.Windows.Forms.ProgressBar();
            this.lblWelzijn = new System.Windows.Forms.Label();
            this.pbWelzijn = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BtnStart = new System.Windows.Forms.Button();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.pbxLogo = new System.Windows.Forms.PictureBox();
            this.pbxStart = new System.Windows.Forms.PictureBox();
            this.pbxAfbeelding = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAfbeelding)).BeginInit();
            this.SuspendLayout();
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblScore.Location = new System.Drawing.Point(11, 209);
            this.lblScore.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(43, 16);
            this.lblScore.TabIndex = 11;
            this.lblScore.Text = "Score";
            this.lblScore.Visible = false;
            this.lblScore.Click += new System.EventHandler(this.lblScore_Click);
            // 
            // btnEten
            // 
            this.btnEten.BackColor = System.Drawing.Color.Navy;
            this.btnEten.Location = new System.Drawing.Point(55, 236);
            this.btnEten.Margin = new System.Windows.Forms.Padding(2);
            this.btnEten.Name = "btnEten";
            this.btnEten.Size = new System.Drawing.Size(117, 262);
            this.btnEten.TabIndex = 10;
            this.btnEten.Text = "eten";
            this.btnEten.UseVisualStyleBackColor = false;
            this.btnEten.Visible = false;
            this.btnEten.Click += new System.EventHandler(this.btnEten_Click);
            // 
            // btnDrinken
            // 
            this.btnDrinken.BackColor = System.Drawing.Color.Red;
            this.btnDrinken.Location = new System.Drawing.Point(639, 251);
            this.btnDrinken.Margin = new System.Windows.Forms.Padding(2);
            this.btnDrinken.Name = "btnDrinken";
            this.btnDrinken.Size = new System.Drawing.Size(124, 262);
            this.btnDrinken.TabIndex = 12;
            this.btnDrinken.Text = "drinken";
            this.btnDrinken.UseVisualStyleBackColor = false;
            this.btnDrinken.Visible = false;
            this.btnDrinken.Click += new System.EventHandler(this.btnDrinken_Click);
            // 
            // lblEten
            // 
            this.lblEten.AutoSize = true;
            this.lblEten.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblEten.Location = new System.Drawing.Point(69, 115);
            this.lblEten.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEten.Name = "lblEten";
            this.lblEten.Size = new System.Drawing.Size(42, 16);
            this.lblEten.TabIndex = 20;
            this.lblEten.Text = "Food:";
            this.lblEten.Visible = false;
            // 
            // pbEten
            // 
            this.pbEten.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pbEten.Location = new System.Drawing.Point(72, 133);
            this.pbEten.Margin = new System.Windows.Forms.Padding(2);
            this.pbEten.Name = "pbEten";
            this.pbEten.Size = new System.Drawing.Size(312, 56);
            this.pbEten.TabIndex = 19;
            this.pbEten.Value = 100;
            this.pbEten.Visible = false;
            // 
            // lblDrinken
            // 
            this.lblDrinken.AutoSize = true;
            this.lblDrinken.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDrinken.Location = new System.Drawing.Point(428, 113);
            this.lblDrinken.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDrinken.Name = "lblDrinken";
            this.lblDrinken.Size = new System.Drawing.Size(48, 16);
            this.lblDrinken.TabIndex = 22;
            this.lblDrinken.Text = "Drinks:";
            this.lblDrinken.Visible = false;
            // 
            // pbDrinken
            // 
            this.pbDrinken.Location = new System.Drawing.Point(432, 133);
            this.pbDrinken.Margin = new System.Windows.Forms.Padding(2);
            this.pbDrinken.Name = "pbDrinken";
            this.pbDrinken.Size = new System.Drawing.Size(317, 56);
            this.pbDrinken.TabIndex = 21;
            this.pbDrinken.Value = 100;
            this.pbDrinken.Visible = false;
            // 
            // lblWelzijn
            // 
            this.lblWelzijn.AutoSize = true;
            this.lblWelzijn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblWelzijn.Location = new System.Drawing.Point(73, 9);
            this.lblWelzijn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelzijn.Name = "lblWelzijn";
            this.lblWelzijn.Size = new System.Drawing.Size(26, 16);
            this.lblWelzijn.TabIndex = 24;
            this.lblWelzijn.Text = "HP";
            this.lblWelzijn.Visible = false;
            this.lblWelzijn.Click += new System.EventHandler(this.lblWelzijn_Click);
            // 
            // pbWelzijn
            // 
            this.pbWelzijn.Location = new System.Drawing.Point(76, 35);
            this.pbWelzijn.Margin = new System.Windows.Forms.Padding(2);
            this.pbWelzijn.Name = "pbWelzijn";
            this.pbWelzijn.Size = new System.Drawing.Size(677, 55);
            this.pbWelzijn.TabIndex = 23;
            this.pbWelzijn.Value = 100;
            this.pbWelzijn.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // BtnStart
            // 
            this.BtnStart.Location = new System.Drawing.Point(236, 520);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(338, 48);
            this.BtnStart.TabIndex = 26;
            this.BtnStart.Text = "Start";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Visible = false;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // btnStartGame
            // 
            this.btnStartGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnStartGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnStartGame.ForeColor = System.Drawing.Color.Red;
            this.btnStartGame.Location = new System.Drawing.Point(259, 411);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(277, 87);
            this.btnStartGame.TabIndex = 28;
            this.btnStartGame.Text = "Start game";
            this.btnStartGame.UseVisualStyleBackColor = false;
            this.btnStartGame.Click += new System.EventHandler(this.btnUitleg_Click);
            // 
            // pbxLogo
            // 
            this.pbxLogo.Image = global::tamagotchi_final_YCH.Properties.Resources.logo;
            this.pbxLogo.Location = new System.Drawing.Point(728, 518);
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new System.Drawing.Size(73, 61);
            this.pbxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxLogo.TabIndex = 30;
            this.pbxLogo.TabStop = false;
            // 
            // pbxStart
            // 
            this.pbxStart.Image = global::tamagotchi_final_YCH.Properties.Resources.start;
            this.pbxStart.Location = new System.Drawing.Point(116, 12);
            this.pbxStart.Name = "pbxStart";
            this.pbxStart.Size = new System.Drawing.Size(555, 393);
            this.pbxStart.TabIndex = 29;
            this.pbxStart.TabStop = false;
            this.pbxStart.Click += new System.EventHandler(this.pbStart_Click);
            // 
            // pbxAfbeelding
            // 
            this.pbxAfbeelding.Location = new System.Drawing.Point(221, 236);
            this.pbxAfbeelding.Margin = new System.Windows.Forms.Padding(2);
            this.pbxAfbeelding.Name = "pbxAfbeelding";
            this.pbxAfbeelding.Size = new System.Drawing.Size(353, 262);
            this.pbxAfbeelding.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxAfbeelding.TabIndex = 25;
            this.pbxAfbeelding.TabStop = false;
            this.pbxAfbeelding.Visible = false;
            // 
            // frmTamagotchiFinal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 580);
            this.Controls.Add(this.pbxLogo);
            this.Controls.Add(this.pbxStart);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.pbxAfbeelding);
            this.Controls.Add(this.lblWelzijn);
            this.Controls.Add(this.pbWelzijn);
            this.Controls.Add(this.lblDrinken);
            this.Controls.Add(this.pbDrinken);
            this.Controls.Add(this.lblEten);
            this.Controls.Add(this.pbEten);
            this.Controls.Add(this.btnDrinken);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnEten);
            this.Name = "frmTamagotchiFinal";
            this.Text = "Tamagotchi YCH";
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAfbeelding)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Button btnEten;
        private System.Windows.Forms.Button btnDrinken;
        private System.Windows.Forms.Label lblEten;
        private System.Windows.Forms.ProgressBar pbEten;
        private System.Windows.Forms.Label lblDrinken;
        private System.Windows.Forms.ProgressBar pbDrinken;
        private System.Windows.Forms.Label lblWelzijn;
        private System.Windows.Forms.ProgressBar pbWelzijn;
        private System.Windows.Forms.PictureBox pbxAfbeelding;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.PictureBox pbxStart;
        private System.Windows.Forms.PictureBox pbxLogo;
    }
}

